//
//  ViewController.swift
//  SamplePickerView
//
//  Created by Kothari, Sagar on 11/14/17.
//  Copyright © 2017 Kothari, Sagar. All rights reserved.
//

import UIKit
import SKFontAwesomeIconPickerView

class ViewController: UIViewController {

  @IBOutlet var iconPicker: SKFontAwesomePickerView!
  @IBOutlet var label: UILabel!
  
  override func viewDidLoad() {
    super.viewDidLoad()
    iconPicker.didSelectClosure = { icon in
      DispatchQueue.main.async {
        self.label.text = icon
      }
    }
  }

}

